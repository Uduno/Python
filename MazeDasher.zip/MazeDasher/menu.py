import pygame
from ui import Button
from config import WIDTH

def show_main_menu(screen, font, start_callback, show_controls_callback):
    buttons = [
        Button("Jouer", (WIDTH // 2 - 100, 250), (200, 50), start_callback, font),
        Button("Commandes", (WIDTH // 2 - 100, 320), (200, 50), show_controls_callback, font),
    ]
    return buttons
