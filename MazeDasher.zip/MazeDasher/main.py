import pygame
import sys
from ui import Button

pygame.init()

# --- Constantes ---
WIDTH, HEIGHT = 640, 720
WHITE = (255, 255, 255)
BG = (30, 30, 30)
FPS = 60

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Menu Principal")
font = pygame.font.SysFont(None, 36)
clock = pygame.time.Clock()

# --- Callbacks ---
def start_game():
    print("Lancer le jeu")
    # Tu peux changer l'état ici ou appeler une fonction
    global running, current_state
    current_state = "game"

def show_controls():
    global current_state
    current_state = "controls"

def return_to_menu():
    global current_state
    current_state = "menu"

# --- Boutons ---
def get_menu_buttons():
    return [
        Button("Jouer", (WIDTH // 2 - 100, 250), (200, 50), start_game, font),
        Button("Commandes", (WIDTH // 2 - 100, 320), (200, 50), show_controls, font),
    ]

def get_controls_buttons():
    return [
        Button("Retour", (WIDTH // 2 - 100, 600), (200, 50), return_to_menu, font),
    ]

# --- Boucle principale ---
current_state = "menu"
running = True

while running:
    screen.fill(BG)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if current_state == "menu":
            for btn in get_menu_buttons():
                btn.handle_event(event)
        elif current_state == "controls":
            for btn in get_controls_buttons():
                btn.handle_event(event)

    if current_state == "menu":
        title = font.render("Menu Principal", True, WHITE)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 150))
        for btn in get_menu_buttons():
            btn.draw(screen)

    elif current_state == "controls":
        title = font.render("Commandes", True, WHITE)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 50))

        commands = [
            "ZQSD ou flèches : se déplacer",
            "Espace : dash",
            "T : transformation",
            "ECHAP : pause / menu"
        ]

        for i, text in enumerate(commands):
            line = font.render(text, True, WHITE)
            screen.blit(line, (50, 150 + i * 40))

        for btn in get_controls_buttons():
            btn.draw(screen)

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
sys.exit()
