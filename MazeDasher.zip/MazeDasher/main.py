import pygame
import sys
from ui import Button
from config import *
from menu import Menu, Controls
from game import Game

pygame.init()

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Menu Principal")
font = pygame.font.SysFont(None, 36)
clock = pygame.time.Clock()

menu = Menu(screen, font)
controls =  Controls(screen, font)
game = Game(screen, font)

current_state = "menu"
running = True

while running:
    clock.tick(60)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if current_state == "menu":
            result = menu.handle_event(event)
            if result == "play":
                game.load_level(0)  
                current_state = "play"
            elif result == "controls":
                current_state = "controls"

        elif current_state == "controls":
            result = controls.handle_event(event)
            if result == "menu":
                current_state = "menu"

        elif current_state == "play":
            result = game.handle_event(event)

            if result == "pause":
                current_state = "pause_popup"
            elif result == "completed":
                current_state = "end_popup"

        elif current_state == "pause_popup":
            result = game.handle_pause_popup()
            if result == "resume":
                current_state = "play"
            elif result == "menu":
                current_state = "menu"

        elif current_state == "end_popup":
            result = game.handle_end_popup()
            if result == "next":
                if game.load_next_level():
                    current_state = "play"
                else:
                    current_state = "menu"
            elif result == "menu":
                current_state = "menu"


    if current_state == "menu":
        menu.draw()
    elif current_state == "controls":
        controls.draw()
    elif current_state == "play":
        game.draw()
    elif current_state == "pause_popup":
        game.draw()
        game.draw_pause_popup()
    elif current_state == "end_popup":
        game.draw()
        game.draw_end_popup()

        

    pygame.display.flip()

pygame.quit()
sys.exit()
